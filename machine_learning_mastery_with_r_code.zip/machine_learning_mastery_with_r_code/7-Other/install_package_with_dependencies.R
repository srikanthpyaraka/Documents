# install package with dependencies

# Install package with dependencies
install.packages("caret", dependencies = c("Depends", "Suggests"))