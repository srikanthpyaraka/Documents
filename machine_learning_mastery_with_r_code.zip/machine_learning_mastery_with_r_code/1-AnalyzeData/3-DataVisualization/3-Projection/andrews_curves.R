# Andrews Curves

# load library
library(andrews)
# load dataset
data(iris)
# generate andres curves
andrews(iris, clr=5, ymax=3)