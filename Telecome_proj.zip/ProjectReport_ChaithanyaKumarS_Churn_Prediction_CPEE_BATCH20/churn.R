#######MAJOR PROJECT - Churn Prediction in Telecom Industry######
rm(list=ls())
#### loading required libraries ####
library(dplyr)
library(reshape2)
library(caTools)
library(ggplot2)
library(vegan)
library(psych)
library(e1071)
library(ROCR)
library(DAAG)
library(MASS)
library(stats)
library(beepr)
library(randomForest)
library(glmnet)
library(nnet)
library(RSNNS) # multi layer perceptron
library(h2o)
library(fpc)
library(cluster)
library(rpart)
#### Setting working directory
setwd("F:/INSOFE/INSOFE Notes & Activity sheets/Major Projects/Telecom_Churn_Data/data")
## working directory to save the plots
plots_and_perfornacemetrics_path = ("F:/INSOFE/INSOFE Notes & Activity sheets/Major Projects/Telecom_Churn_Data/data/Graphs and Performance metrics")
#### Load data in csv format in to R's memory
churn = read.csv("Data.csv",header = T)
## Preprocessing steps ####
#Ckecking for dimensions of data
dim(churn) # 25000 rows and 111 columns,including target
#summary of data
summary(churn) 
# Structure of data
str(churn) # all variables are loded as int or num
# checking for NA values
sum(is.na(churn)) # 0
# check for duplicates
if(nrow(unique(churn)) == nrow(churn)){
    print("No Duplicates")
}

#Moving the target variable to the last column
churn = churn[,c(setdiff(names(churn),"target"),"target")]
names(churn)
#Converting everything except target into numeric
churn[,-ncol(churn)] = apply(churn[,-ncol(churn)],2,as.numeric)
#Converting target to factor
churn$target = as.factor(churn$target)
#Setting seed 
set.seed(100)
## Plots ####

#checking for class imbalance
table(churn$target)
# checking for the percantage of churned customers in the data
apr = table(churn$target)[2]/sum(table(churn$target))*100 #31.668
# splitting the data using stratified sampling technique
set.seed(100);s = sample.split(churn$target,SplitRatio = 0.7)

df1 = churn[s,c(1:50,ncol(churn))]
# converting the data into long format for plotting using gg plot
df1.m = melt(df1,id.vars = "target")

## setting y limits to 0,1500 for better vizualization
# plotting unstandardized data, this will also help us look at how the data is 
# distributed
## setting y limits to 0,1500 for better vizualization
jpeg("Boxplot of Churn data 1-50.jpeg",height = 550,width = 1000,quality = 100)
ggplot(df1.m,aes(x=variable,y= value),las=2,cex = 0.2) +
    coord_cartesian(ylim=c(0,1500))+
    geom_boxplot(aes(fill=df1.m$target))+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))+
    labs(title = "Boxplot of Churn data for 1-50 attributes")
dev.off()

df2 = churn[s,c(51:ncol(churn))]
df2.m = melt(df2,id.vars = "target")


jpeg("Boxplot of Churn data 51-100.jpeg",height = 550,width = 1000,quality = 100)
ggplot(df2.m,aes(x=variable,y= value),las=2,cex = 0.2) +
    coord_cartesian(ylim=c(0,1500))+
    geom_boxplot(aes(fill=df2.m$target))+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))+
    labs(title = "Boxplot of Churn data for 51-100 attributes")
dev.off()

## we can see that most of the attributes are not normally distributed
#churn_scaled = scale(churn_stand,center = T,scale = T)
#center =T will substract the mean of column from every element in the column
#scale = T will divide the centered data with the sd of the column
#boxplot(churn_scaled,main="Scaled churn data",las = 2, cex =0.5)

## standardising the variables with range method ####
churn_stand = decostand(churn[,-ncol(churn)],method = "standardize")
churn_stand$target = churn$target

# Plotting standardized data
df3 = churn_stand[s,c(1:50,ncol(churn_stand))]
df3.m = melt(df3,id.vars = "target")

jpeg("Boxplot of Standardized Churn data for 1-50 attributes.jpeg",height = 550,width = 1000,quality = 100)
    coord_cartesian(ylim=c(-4,6))+
    geom_boxplot(aes(fill=df3.m$target))+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))+
    labs(title = "Boxplot of Standardized Churn data for 1-50 attributes")
dev.off()

df4 = churn_stand[s,c(51:ncol(churn_stand))]
df4.m = melt(df4,id.vars = "target")
jpeg("Boxplot of Standardized Churn data for 51-100 attributes.jpeg",height = 550,width = 1000,quality = 100)
ggplot(df4.m,aes(x=variable,y= value),las=2,cex = 0.2) +
    coord_cartesian(ylim=c(-4,6))+
    geom_boxplot(aes(fill=df4.m$target))+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))+
    labs(title = "Boxplot of Standardized Churn data for 1-50 attributes")
dev.off()

# Checking for outliers in the standardized data
x = apply(churn_stand[,-ncol(churn_stand)],2,function (x) boxplot(x)$out)

#boxplot(churn[,-ncol(churn)]) # with all the data
outlier_data = lapply(churn_stand[,-ncol(churn_stand)],function (x) boxplot(x)$out)
outliers_in_each =data.frame("Number of Outliers" = sapply(outlier_data,length))
outliers_in_each$Attribute = rownames(outliers_in_each)

#ordering the columns in descending order of the outliers
outliers_in_each = outliers_in_each[order(outliers_in_each$Number.of.Outliers,decreasing = T),]
outliers_in_each = outliers_in_each[,c(2,1)]
## writing the number of outliers into a csv file
write.csv(outliers_in_each,"Number of outliers in each after stand.csv",row.names = F)
# top 10 columns with outliers
outliers_in_each[1:10,]
#ggplot(df3.m,aes(x=variable,y=value))+geom_jitter() 


#apply(churn_stand[,-ncol(churn_stand)],2,hist)



#churn[,ncol(churn)]
#cor.plot(churn[,-ncol(churn)])

## skewness and kurtosis for the standardized data####


kurt_num_data = data.frame("kurtosis" = apply(churn_stand[-ncol(churn_stand)],2,function(x){kurtosis(x)}))

skewness_num_data = data.frame("skewness" = apply(churn_stand[-ncol(churn_stand)],2,skewness))
kurt_skew_num_data = data.frame(colnames(churn_stand[-ncol(churn_stand)]),kurt_num_data$kurtosis,skewness_num_data$skewness)

names(kurt_skew_num_data) = c("col_names","kurtosis","skewness")
head(kurt_skew_num_data)

#### ####
# for (i in 1:length(colnames(churn_stand)))
# {
#     if (kurtosis(churn_stand[,i])!=0)
#     {
#         churn_stand[,i] = log(churn[,i])
#     }
# }
# head(churn_stand)
# plot(churn_stand$s6.new.rev.p2.m2)
## correlation matrix ####
# cor_mat = cor(churn_stand)
# cor_mat_abs = abs(cor_mat)
# cor_mat_abs[lower.tri(cor_mat_abs,diag = T)] = 0
# cor_mat_abs[1:3,1:3]
# table_abs_cor = as.data.frame(as.table(cor_mat_abs))
# table_abs_cor_ord = table_abs_cor[order(table_abs_cor$Freq,decreasing = T),]
# head(table_abs_cor_ord)
# cor_morethan_0.80 = filter(table_abs_cor_ord,table_abs_cor_ord$Freq>0.80)
# #cor_morethan_0.95 = table_abs_cor_ord[,table_abs_cor_ord$Freq>0.95]
# View(cor_morethan_0.80)
# list_0.80_cols = unlist(as.list(unique(cor_morethan_0.80$Var1)))
# length(list_0.80_cols)
# churn_cor1 = subset(churn,select = -c(list_0.80_cols))
# ncol(churn_cor1)


## creating an object to save all the model performances 
rm(model_performances)
model_performances = data.frame("Model"=NA,"Accuracy on train data"=NA,
                       "Recall on train data" =NA,
                       "FPR on train data"= NA,
                       "Accuracy on test data"=NA,
                       "Recall on test data" =NA,
                       "FPR on test data"=NA,"Max lift" = NA)
### log reg ####
#taking stratified sample as there is a class imbalance

train_glm = subset(churn_stand,s==TRUE)
test_glm = subset(churn_stand, s == FALSE)
glmstart = Sys.time()
glm_model = glm(target~.,data= train_glm,family = "binomial")
glmtime = Sys.time() - glmstart
glmtime # 3.884428 secs
summary(glm_model)

pred_train_glm_model = predict(glm_model,train_glm,type= "response")
#### performance of glm_model

ROCR_glm_model_pred = prediction(pred_train_glm_model,train_glm$target)
ROCR_glm_model_perf = performance(ROCR_glm_model_pred,'tpr','fpr')
## AUC of glm model
AUC_logreg_model = as.numeric(performance(ROCR_glm_model_pred,'auc')@y.values) *100 
AUC_logreg_model #85.65973
jpeg("ROCR curve for logistic regression using all the variables.jpeg",height = 550,width = 1000,quality = 100)
plot(ROCR_glm_model_perf,colorize= T,print.cutoffs.at=c(seq(0,1,0.1)),
     main="ROCR curve for Logistic Regression using all the variables(on train data)",cex = 1.5)
dev.off()
#In the performance object, we have the slot alpha values, 
#which corresponds to the cutoff in this case, and y.values correspond to 
# 'tpr' rates, x.values corr to 'fpr' rates.

cutoffs1 = data.frame(cut=ROCR_glm_model_perf@alpha.values[[1]], fpr=ROCR_glm_model_perf@x.values[[1]], 
                       tpr=ROCR_glm_model_perf@y.values[[1]])
cutoffs1 = cutoffs1[order(cutoffs1$tpr, decreasing=TRUE),]

filter(cutoffs1,fpr<0.19,tpr>0.7)

# considering 0.3 cutoff 
## train accuracy for glm 
pred_train_glm_model_table = table(pred_train_glm_model>0.30,train_glm$target)
accu_train_glm = sum(diag(pred_train_glm_model_table))/sum(pred_train_glm_model_table)*100
accu_train_glm #  77.13714
## train recall for glm
recall_train_glm = pred_train_glm_model_table[2,2]/sum(pred_train_glm_model_table[,2])*100
recall_train_glm #78.32912
## fpr for glm 
fpr_glm_train = pred_train_glm_model_table[2,1]/sum(pred_train_glm_model_table[,1])*100
fpr_glm_train #18.92457
## test accuracy for glm
glmteststart = Sys.time()
pred_test_glm_model = predict(glm_model,test_glm[,-ncol(test_glm)],type = "response")
glmtesttime = Sys.time() - glmteststart
glmtesttime #0.02323008
pred_test_glm_model_table = table(pred_test_glm_model>0.3,test_glm$target)
accu_test_glm = sum(diag(pred_test_glm_model_table))/sum(pred_test_glm_model_table)*100
accu_test_glm #77.14667
recall_test_glm = pred_test_glm_model_table[2,2]/sum(pred_test_glm_model_table[,2])*100
recall_test_glm #78.14737
fpr_glm_test = pred_test_glm_model_table[2,1]/sum(pred_test_glm_model_table[,1])*100
fpr_glm_test #23.31707
##max lift with log reg model
maxlift_logreg  = recall_test_glm/apr
maxlift_logreg
# glm on all attributes performance
model_performances = rbind(model_performances,c("Logistic Regression on all attributes",accu_train_glm,
                            recall_train_glm,
                            fpr_glm_train,accu_test_glm,
                            recall_test_glm,fpr_glm_test,maxlift_logreg))

#write.csv(model_performances,"model performances.csv",row.names = T,col.names=F)

## accuracy,recall and false positive rate for various cut offs on test data####
for (i in c(seq(0,1,0.1))){
    pred_test_glm_model = predict(glm_model,test_glm[,-ncol(test_glm)])
    pred_test_glm_model_table = table(pred_test_glm_model>i,test_glm$target)
    accu_test_glm = sum(diag(pred_test_glm_model_table))/sum(pred_test_glm_model_table)
    recall_test_glm_model = pred_test_glm_model_table[2,2]/sum(pred_test_glm_model_table[,2])
    fpr_test_glm_model = pred_test_glm_model_table[2,2]/sum(pred_test_glm_model_table[,2])*100
    print (paste("cutoff",i,"Accuracy:",accu_test_glm,"Recall:",recall_test_glm_model,
                 "False Positive Rate",fpr_test_glm_model))
}
## test recall for glm 
recall_test_glm = pred_test_glm_model_table[2,2]/sum(pred_test_glm_model_table[,2])*100
recall_test_glm #50.90526


## glm low VIF vars ####

vif_glm = vif(glm_model)
vif_lessthan_4 = data.frame(churn_stand[,vif_glm<4],"target" =churn_stand$target)
vif_lessthan_6 = data.frame(churn_stand[,vif_glm<6],"target" =churn_stand$target)
vif_lessthan_8 = data.frame(churn_stand[,vif_glm<8],"target" =churn_stand$target)
col_viflessthan8 = colnames(vif_lessthan_8[,-ncol(vif_lessthan_8)])
col_viflessthan6= colnames(vif_lessthan_6[,-ncol(vif_lessthan_6)])
col_viflessthan4= colnames(vif_lessthan_4[,-ncol(vif_lessthan_4)])
#write.file(col_viflessthan8,"Columns with VIFlessthan8.txt",col.names=F,row.names = F)
#write.file(col_viflessthan6,"Columns with VIFlessthan6.txt",col.names=F,row.names = F)
#write.file(col_viflessthan4,"Columns with VIFlessthan4.txt",col.names=F,row.names = F)

## for vif <4 ####
split1 = s

train_data_4vif = subset(vif_lessthan_4,split1==TRUE)
train_data_4vif =subset(vif_lessthan_4, split1 == FALSE)

glm_4vif = glm(target~.,data=train_data_4vif,family = "binomial")
glm_4vif_train_pred = predict(glm_4vif,train_data_4vif,type="response")

ROCR_pred_4vif = prediction(glm_4vif_train_pred,train_data_4vif$target)
ROCR_perf_4vif = performance(ROCR_pred_4vif,'tpr','fpr')
plot(ROCR_perf_4vif,colorize= T,print.cutoffs.at=c(seq(0,1,0.2)))

AUC_4vif = as.numeric(performance(ROCR_pred_4vif,'auc')@y.values)*100
AUC_4vif # 80.37399

cutoffs_4vif = data.frame(cut=ROCR_perf_4vif@alpha.values[[1]], fpr=ROCR_perf_4vif@x.values[[1]], 
                      tpr=ROCR_perf_4vif@y.values[[1]])
cutoffs_4vif = cutoffs_4vif[order(cutoffs_4vif$tpr, decreasing=TRUE),]
filter(cutoffs_4vif,fpr<0.1,tpr>.4)
## very low tpr and high fpr
## for vif <6 ####
split1 = s

train_data_6vif = subset(vif_lessthan_6,split1==TRUE)
train_data_6vif =subset(vif_lessthan_6, split1 == FALSE)

glm_6vif = glm(target~.,data=train_data_6vif,family = "binomial")
glm_6vif_train_pred = predict(glm_6vif,train_data_6vif,type="response")

ROCR_pred_6vif = prediction(glm_6vif_train_pred,train_data_6vif$target)
ROCR_perf_6vif = performance(ROCR_pred_6vif,'tpr','fpr')
plot(ROCR_perf_6vif,colorize= T,print.cutoffs.at=c(seq(0,1,0.2)))

AUC_6vif = as.numeric(performance(ROCR_pred_6vif,'auc')@y.values)*100
AUC_6vif # 80.50628

cutoffs_6vif = data.frame(cut=ROCR_perf_6vif@alpha.values[[1]], fpr=ROCR_perf_6vif@x.values[[1]], 
                          tpr=ROCR_perf_6vif@y.values[[1]])
cutoffs_6vif = cutoffs_6vif[order(cutoffs_6vif$tpr, decreasing=TRUE),]
filter(cutoffs_6vif,fpr<0.1,tpr>.5)
## very low tpr and high fpr

####for vif 8 ####
train_data = subset(vif_lessthan_8,s==TRUE)
test_data= subset(vif_lessthan_8, s == FALSE)
ncol(train_data)

vglm_train_model = glm(target~.,data = train_data,family = "binomial")

## ROCR for low VIF model 

vglm_model_train_pred = predict(vglm_train_model,train_data,type="response")

ROCR_lowvif_pred = prediction(vglm_model_train_pred,train_data$target)
ROCR_lowvif_perf = performance(ROCR_lowvif_pred,'tpr','fpr')
jpeg("ROCR for glm on vif less than 8.jpeg",width = 1000,height = 550,quality = 100)
plot(ROCR_lowvif_perf,colorize= T,print.cutoffs.at=c(seq(0,1,0.2)),main = "ROCR for Logistic Regression (on VIF less than 8 attributes).")
dev.off()
AUC_low_vif_model = as.numeric(performance(ROCR_lowvif_pred,'auc')@y.values)*100
AUC_low_vif_model # 82.97243

cutoffs2 = data.frame(cut=ROCR_lowvif_perf@alpha.values[[1]], fpr=ROCR_lowvif_perf@x.values[[1]], 
                       tpr=ROCR_lowvif_perf@y.values[[1]])
cutoffs2 = cutoffs2[order(cutoffs2$tpr, decreasing=TRUE),]
filter(cutoffs2,fpr<0.2,tpr>.7)

## using 0.33 cutoff


vglm_train_table = table(vglm_model_train_pred>0.33,train_data$target)
vglm_train_table
accuracy_vglm_train = sum(diag(vglm_train_table))/sum(vglm_train_table)*100
accuracy_vglm_train # 76.44571

recall_vglm_train = vglm_train_table[2,2]/sum(vglm_train_table[,2])*100
recall_vglm_train # 72.17611

fpr_vglm_train = vglm_train_table[2,1]/sum(vglm_train_table[,1])*100
fpr_vglm_train #21.57551

lowvif_glm_model_test_pred = predict(vglm_train_model,test_data[,-ncol(test_data)],type="response")
lowvif_glm_test_table = table(lowvif_glm_model_test_pred >0.33,test_data$target)
lowvif_glm_test_table
accuracy_vgmltest = sum(diag(lowvif_glm_test_table))/sum(lowvif_glm_test_table)*100
accuracy_vgmltest # 76.06667
recall_vglm_test = lowvif_glm_test_table[2,2]/sum(lowvif_glm_test_table[,2])*100
recall_vglm_test # 71.53684
fpr_vglm_test = lowvif_glm_test_table[2,1]/sum(lowvif_glm_test_table[,1])*100
fpr_vglm_test # 21.83415
#max lift 
maxlift_vglm = recall_vglm_test/apr
maxlift_vglm
# adding the performances to the model_performances 
model_performances = rbind(model_performances,c("Logistic Regression on attributes with VIF less than 8",
                                                accuracy_vglm_train,recall_vglm_train,fpr_vglm_train,
                                                accuracy_vgmltest,recall_vglm_test,fpr_vglm_test,
                                                maxlift_vglm))

#### best model after step aic on VIF ####
### step AIC ##
ncol(vif_lessthan_8)

glm_step_aic = stepAIC(glm_train_model,direction = "both")

#Step:  AIC=16258.15
stepaic_bestmodel = glm(target ~ s2.rch.val.p6 + s8.mbl.p2 + s2.rch.val.l67 + s7.s4.day.no.mou.p2.p4 + 
                            s7.s5.s4.day.nomou.p4 + s8.og.rev.p3 + s8.ic.mou.all.p3 + 
                            s6.rtd.mou.p2.m2 + s7.rev.p2.p6 + s2.s4.day.no.mou.p2 + s7.rtd.mou.l21.p6 + 
                            s8.og.mou.all.p6 + s7.rtd.mou.m1.m2 + prop.og.mou.tot.mou.all.p2 + 
                            s1.new.rev.m2 + s4.rch.val.gt.30.p2 + s4.low.blnc.ins.p6 + 
                            s4.dec.ins.p2 + prop.og.mou.tot.mou.all.p6 + s3.og.rev.all.m2,data = train_data,family = "binomial")


aic_model_train_pred = predict(stepaic_bestmodel,train_data,type = "response")


aic_model_ROCR_pred = prediction(aic_model_train_pred,train_data$target)
aic_model_ROCR_perf = performance(aic_model_ROCR_pred,'tpr','fpr')
jpeg("STEP AIC BEST MODEL.jpeg",width = 1000,height = 550,quality = 100)
plot(aic_model_ROCR_perf,colorize = T,print.cutoffs.at = c(0,1,0.1),
     main = "Logistic Regression performance on attributes obtained from step AIC")
dev.off() 
## auc of aic model
AUC_aic_model = as.numeric(performance(aic_model_ROCR_pred,'auc')@y.values)*100 ## 82.96574
AUC_aic_model #82.96574
cutoffs3 = data.frame(cut=aic_model_ROCR_perf@alpha.values[[1]], 
                      fpr=aic_model_ROCR_perf@x.values[[1]], 
                      tpr=aic_model_ROCR_perf@y.values[[1]])
cutoffs3 = cutoffs3[order(cutoffs3$tpr, decreasing=TRUE),]
filter(cutoffs3,fpr<0.2,tpr>0.7)

## cutoff 0.34
aic_train_pred_table = table(aic_model_train_pred>0.34,train_data$target)
accuracy_bestmodel_aic_train = sum(diag(aic_train_pred_table))/sum(aic_train_pred_table)*100
accuracy_bestmodel_aic_train #  76.70286
recall_aic_model_train = aic_train_pred_table[2,2]/sum(aic_train_pred_table[,2])*100
recall_aic_model_train ## 70.89498
fpr_aic_train = aic_train_pred_table[2,1]/sum(aic_train_pred_table[,1])*100
fpr_aic_train # 20.60545

# for test data
aic_model_test_pred = predict(stepaic_bestmodel,test_data[,-ncol(test_data)],type = "response")
aic_test_pred_table = table(aic_model_test_pred>0.34,test_data$target)
accuracy_bestmodel_aic_test = sum(diag(aic_test_pred_table))/sum(aic_test_pred_table)*100
accuracy_bestmodel_aic_test#  76.42667
recall_aic_model_test = aic_test_pred_table[2,2]/sum(aic_test_pred_table[,2])*100
recall_aic_model_test ## 70.18947
fpr_aic_test = aic_test_pred_table[2,1]/sum(aic_test_pred_table[,1])*100
fpr_aic_test #20.68293
#max lift 
maxlift_stepaic = recall_aic_model_test/apr
maxlift_stepaic
# adding the performances to the model_performances 
model_performances = rbind(model_performances,c("Step AIC best model on attributes with VIF less than 8",
                                                accuracy_bestmodel_aic_train,
                                                recall_aic_model_train,
                                                fpr_aic_train,
                                                accuracy_bestmodel_aic_test,
                                                recall_aic_model_test,
                                                fpr_aic_test,maxlift_stepaic))



#using PCA for extracting new features ####


pca_data = vif_lessthan_8
pca = princomp(pca_data[,-ncol(pca_data)])
summary(pca)
#scores
scores_pca = pca$scores
head(scores_pca)
#top 15 scores 
target = vif_lessthan_8$target
top_5_scores = (scores_pca[,1:5]) # explaining 99% of the data
pca_5 = data.frame(top_5_scores,"target" = vif_lessthan_8$target) 
table(pca_5$target)
#splitting data into train and test
train_pca = subset(pca_5,s == T)
test_pca = subset(pca_5,s == F)

glm_pca= glm(target~., data =pca_5,family="binomial")
train_pred = predict(glm_pca,train_pca[,-ncol(train_pca)],type= 'response')
test_pred = predict(glm_pca,test_pca[,-ncol(test_pca)],type= 'response')
## pref objects 
ROCR_pred_glm_pca = prediction(train_pred,train_pca$target)
ROCR_perf_glm_pca = performance(ROCR_pred_glm_pca,'tpr','fpr')
plot(ROCR_perf_glm_pca,colorize= T,print.cutoffs.at = seq(0,1,0.1))
tr_t = table(train_pred>0.5,train_pca$target)
ts_t = table(test_pred>0.5,test_pca$target)
accuracy_train = sum(diag(tr_t))/sum(tr_t) *100
recall_train = tr_t[2,2]/sum(tr_t[,2]) *100
fpr_train = tr_t[2,1]/sum(tr_t[1,]) *100
accuracy_test = sum(diag(ts_t))/sum(ts_t) *100
recall_test = ts_t[2,2]/sum(ts_t[,2]) *100
fpr_test = ts_t[2,1]/sum(ts_t[1,]) *100
##max lift
maxlift_pca = recall_test/apr
model_performances = rbind(model_performances,c("Logistic regression on 5 pca components(22 attributes considered)",
                                                accuracy_train,recall_train,fpr_train,
                                                accuracy_test,recall_test,fpr_test,maxlift_pca))

####SVM####
t = Sys.time()
svm_pca_churn = svm(x = train_data[,-ncol(train_data)], y=train_data$target, method =" C-classification")
Sys.time() - t #

svm_pred_train = predict(svm_pca_churn,train_data[,-ncol(train_data)])
svm_m_train_pred_table = table(svm_pred_train,train_data$target)
accuracy_train_svm = sum(diag(svm_m_train_pred_table))/sum(svm_m_train_pred_table) *100
accuracy_train_svm #80.53143
recall_train_svm = svm_m_train_pred_table[2,2]/sum(svm_m_train_pred_table[,2]) *100
recall_train_svm #53.96969
fpr_train_svm = svm_m_train_pred_table[2,1]/sum(svm_m_train_pred_table[,1]) *100
fpr_train_svm #4 21.333
svm_pred_test = predict(svm_pca_churn,test_data[,-ncol(test_data)])
svm_m_test_pred_table = table(svm_pred_test,test_data$target)
accuracy_test_svm = sum(diag(svm_m_test_pred_table))/sum(svm_m_test_pred_table) *100
accuracy_test_svm #78.38667
recall_test_svm = svm_m_test_pred_table[2,2]/sum(svm_m_test_pred_table[,2])*100
recall_test_svm #49.09474
fpr_test_svm = svm_m_test_pred_table[2,1]/sum(svm_m_test_pred_table[,1]) *100
fpr_test_svm # 8.039024
beep(4)
##max lift 
maxlift_svm = recall_test_svm/apr

model_performances= rbind(model_performances,c("SVM on 22 attributes",accuracy_train_svm,recall_train_svm,
                                               fpr_train_svm,accuracy_test_svm,recall_test_svm,fpr_test_svm
                                               ,maxlift_svm))

### Random Forest ####
# random forest on all the attributes
train_rf = train_glm
test_rf = test_glm

randomForest_churn = randomForest(target~.,data=train_rf ,ntree= 12)
varimp = data.frame(randomForest_churn$importance)
varimp$names = rownames(varimp)
top = varimp[order(varimp$MeanDecreaseGini,decreasing = T),]
#varimp plot
varImpPlot(randomForest_churn,main ="Variable importance plot")
jpeg("Variable importance plot.jpeg",width = 650,height = 750,quality = 100)
varImpPlot(randomForest_churn,main ="Variable importance plot")
dev.off()
#writing the var imp to file
top = top[c(2,1)]
write.csv(top,"var_imp_decreasing_order.csv",row.names = F)
#cat(top$names,file="var_imp_decreasing_order.txt",sep="\n")
top_x = varimp[order(varimp$MeanDecreaseGini,decreasing = T),]
mabc = model_performances
####glm on rf important attributes for 5- 8 attributes ####
for (i in 5:8){
    churn_imp = subset(churn_stand,select = c(top_x[1:i,]$names,"target"))
    ncol(churn_imp)
    names(churn_imp)
    churn_imp_train = subset(churn_imp,s==T)
    churn_imp_test = subset(churn_imp,s== F)
    
    rf_imp_svm = svm(target~.,data = churn_imp_train,method ="classification")
    summary(rf_imp_svm)

#     train_pred_rf_svm = predict(rf_imp_svm,churn_imp_train,type = "response")
#     ROCR_rf_pred = prediction(train_pred_rf_svm,churn_imp_train$target)
#     ROCR_rf_perf = performance(ROCR_rf_pred,'tpr','fpr')
# 
#     plot(ROCR_rf_perf,colorize = T,print.cutoffs.at = seq(0,1,0.1))
#     cutoffs2 = data.frame(cut=ROCR_rf_perf@alpha.values[[1]], fpr=ROCR_rf_perf@x.values[[1]], 
#                            tpr=ROCR_rf_perf@y.values[[1]])
#     cutoffs2 = cutoffs2[order(cutoffs2$tpr, decreasing=TRUE),]
#     head(subset(cutoffs2, fpr < 0.25))

    train_pred_rf_svm = predict(rf_imp_svm,churn_imp_train[,-ncol(churn_imp_train)],type="class")
    train_pred_rf_svm_table = table(train_pred_rf_svm,churn_imp_train$target)
    acc_rf_imp_train = sum(diag(train_pred_rf_svm_table))/sum(train_pred_rf_svm_table)
    acc_rf_imp_train  #0.7504571
    recall_rf_imp_train = train_pred_rf_svm_table[2,2]/sum(train_pred_rf_svm_table[,2]) *100
    recall_rf_imp_train #75.49621
    fpr_rf_imp_train = train_pred_rf_svm_table[2,1]/sum(train_pred_rf_svm_table[,1]) *100
    test_pred_rf_svm = predict(rf_imp_svm,churn_imp_test[,-ncol(churn_imp_test)],type = "class")
    test_pred_rf_svm_table = table(test_pred_rf_svm,churn_imp_test$target)
    acc_rf_imp_test = sum(diag(test_pred_rf_svm_table))/sum(test_pred_rf_svm_table)
    acc_rf_imp_test # 0.7512
    recall_rf_imp_test = test_pred_rf_svm_table[2,2]/sum(test_pred_rf_svm_table[,2])*100
    recall_rf_imp_test # 75.41053
    fpr_rf_imp_test = test_pred_rf_svm_table[2,1]/sum(test_pred_rf_svm_table[,1]) *100
    fpr_rf_imp_test

    x = fpr_rf_imp_test/apr  
    n =paste("svm on first",i,"important attributes")
    model_performances = rbind(model_performances,c(n,acc_rf_imp_train,recall_rf_imp_train,
                                                          fpr_rf_imp_train,acc_rf_imp_test,
                                                          recall_rf_imp_test,fpr_rf_imp_test,x))
}
beep(8)

##### glmnet #####
### ridge on 22 attributes####

glmnet_train = as.matrix(train_data[,-ncol(train_data)])
train_target = as.double(train_data$target)
glmnet_test = as.matrix((test_data[,-ncol(test_data)]))
test_target = as.double(test_data$target)

cv.ridge = cv.glmnet(glmnet_train, train_target, family='binomial', alpha=0, type.measure='auc')
plot(cv.ridge,xvar="lambda",label=TRUE)
plot(cv.ridge,xvar="dev",label=TRUE)
plot(cv.ridge)
cv.ridge$lambda.min
cv.ridge$lambda.1se
coef(cv.ridge, s=cv.ridge$lambda.min)
ridge_pred_train = predict(cv.ridge,glmnet_train,type="response")
ROCR_ridge_pred = prediction(ridge_pred_train,train_target)
ROCR_ridge_perf =performance(ROCR_ridge_pred,'tpr','fpr')
plot(ROCR_ridge_perf,colorize = T,print.cutoffs.at = c(0,1,0.1))
AUC_ridge = as.numeric(performance(ROCR_ridge_pred,'auc')@y.values) *100
AUC_ridge #82.59571
cutoffsR = data.frame(cut=ROCR_ridge_perf@alpha.values[[1]], fpr=ROCR_ridge_perf@x.values[[1]], 
                      tpr=ROCR_ridge_perf@y.values[[1]])
cutoffsR = cutoffsR[order(cutoffsR$tpr, decreasing=TRUE),]
head(subset(cutoffsR, fpr < 0.25))
## selecting .29 cutoff
ridge_train_table = table(ridge_pred_train>0.29,train_target)
accuracy_train_ridge = sum(diag(ridge_train_table))/sum(ridge_train_table)*100
accuracy_train_ridge #74.45143
recall_train_ridge = ridge_train_table[2,2]/sum(ridge_train_table[,2])*100
recall_train_ridge #76.16384
fpr_train_ridge = ridge_train_table[2,1]/sum(ridge_train_table[,1])*100
fpr_train_ridge #26.3422

# on test data 
ridge_pred_test= predict(cv.ridge,glmnet_test,type = "response")

## selecting .29 cutoff
ridge_test_table = table(ridge_pred_test>0.29,test_target)
accuracy_test_ridge = sum(diag(ridge_test_table))/sum(ridge_test_table)*100
accuracy_test_ridge #76.82667
recall_test_ridge = ridge_test_table[2,2]/sum(ridge_test_table[,2])*100
recall_test_ridge #36.42105
fpr_test_ridge = ridge_test_table[2,1]/sum(ridge_test_table[,1])*100
fpr_test_ridge #4.44878
maxlift_ridge = fpr_test_ridge/apr
maxlift_ridge

model_performances = rbind(model_performances,c("Ridge",accuracy_train_ridge,recall_train_ridge,
                                                fpr_train_ridge,accuracy_test_ridge,
                                                recall_test_ridge,fpr_test_ridge,maxlift_ridge))
## lasso regression on 22 attributes####
cv.lasso = cv.glmnet(glmnet_train, train_target, family='binomial', alpha=1, type.measure='auc')
plot(cv.lasso)
cv.lasso$lambda.min
cv.lasso$lambda.1se
coef(cv.lasso, s=cv.lasso$lambda.min)
summary(cv.lasso)
# train data performance 
lasso_train_pred = predict(cv.lasso,glmnet_train,type= "response")
nrow(lasso_train_pred)
# lasso performance object
ROCR_lasso_train = prediction(lasso_train_pred,train_target)
ROCR_lasso_perf = performance(ROCR_lasso_train,'tpr','fpr')
AUC_lasso = as.numeric(performance(ROCR_lasso_train,'auc')@y.values)*100
AUC_lasso # 82.62179
cutoffsL = data.frame(cut=ROCR_lasso_perf@alpha.values[[1]], fpr=ROCR_lasso_perf@x.values[[1]], 
                      tpr=ROCR_lasso_perf@y.values[[1]])
cutoffsL = cutoffsL[order(cutoffsR$tpr, decreasing=TRUE),]
filter(cutoffsL,fpr<0.2,tpr >0.7)
plot(ROCR_lasso_perf,colorize = T,print.cutoffs.at = seq(0,1,0.1))
# selecting 0.34 cutoff
lasso_train_table = table(lasso_train_pred>0.34,train_target)
accuracy_train_lasso = sum(diag(lasso_train_table))/sum(lasso_train_table)*100
accuracy_train_lasso #76.84571
recall_train_lasso = lasso_train_table[2,2]/sum(lasso_train_table[,2])*100
recall_train_lasso #70.26344
fpr_train_lasso = lasso_train_table[2,1]/sum(lasso_train_table[,1])*100
fpr_train_lasso #20.1037
# on test data
lasso_test_pred = predict(cv.lasso,glmnet_test,type= "response")
lasso_test_table = table(lasso_test_pred>0.34,test_target)
accuracy_test_lasso = sum(diag(lasso_test_table))/sum(lasso_test_table)*100
accuracy_test_lasso #76.61333
recall_test_lasso = lasso_test_table[2,2]/sum(lasso_test_table[,2])*100
recall_test_lasso #69.22105
fpr_test_lasso = lasso_test_table[2,1]/sum(lasso_test_table[,1])*100
fpr_test_lasso #19.96098
maxlift_lasso = recall_test_lasso/apr
maxlift_lasso
model_performances = rbind(model_performances,c("Lasso",accuracy_train_lasso,recall_train_lasso,fpr_train_lasso,
                                                accuracy_test_lasso,recall_test_lasso,fpr_test_lasso,maxlift_lasso))

###### neural net on 22 attr#####

nnet_model = nnet(target~.,train_data,size = 2,rang = 0.1, decay = 5e-4,maxit = 700)
nnet_pred_train = predict(nnet_model,train_data[,-ncol(train_data)],type = "class")
nnet_train_table = table(nnet_pred_train,train_data$target)
accu_nnet_train = sum(diag(nnet_train_table))/sum(nnet_train_table)*100
accu_nnet_train #78.78857
recall_nnet_train = nnet_train_table[2,2]/sum(nnet_train_table[,2])*100
recall_nnet_train #55.08842
fpr_nnet_train = nnet_train_table[2,1]/sum(nnet_train_table[,1])*100
fpr_nnet_train #10.22746

# for test data 
nnet_pred_test = predict(nnet_model,test_data[,-ncol(test_data)],type = "class")
nnet_test_table = table(nnet_pred_test,test_data$target)
accu_nnet_test = sum(diag(nnet_test_table))/sum(nnet_test_table)*100
accu_nnet_test # 78.58667
recall_nnet_test = nnet_test_table[2,2]/sum(nnet_test_table[,2])*100
recall_nnet_test #54.27368
fpr_nnet_test = nnet_test_table[2,1]/sum(nnet_test_table[,1])*100
fpr_nnet_test #10.14634
maxlift_nnet = recall_nnet_test/apr
maxlift_nnet
# ####mlp ####
# 
# mlp_model = mlp(y=as.numeric(train_data$target),x=as.matrix(train_data[,-ncol(train_data)]),size = c(14),linOut = F)
# predictions = predict(mlp_model,train_data[,-ncol(train_data)],type="class")
# confusionMatrix(train_data$target,predictions)
# fitted.values(mlp_model)
# ROCR_pred_mlp = pre

#####################H2o glm###################################################
# Load H2o library
#install.packages("h2o")


# Start H2O on the local machine using all available cores
#localH2O = h2o.init(nthreads = -1)
## on all the data
write.csv(train_glm,"train_glm.csv",row.names=F)
write.csv(test_glm,"test_glm.csv",row.names=F)
localH2O = h2o.init(ip = "localhost", port = 54321, startH2O = TRUE,
                    min_mem_size = "3g")
localH2O = h2o.init()

train.hex  = h2o.uploadFile(localH2O, path = "train_glm.csv",header = TRUE, sep = ",")
test.hex  = h2o.uploadFile(localH2O, path = "test_glm.csv",header = TRUE, sep = ",")

GLM_Model.hexL1 = h2o.glm(y = "target", x = setdiff(names(train.hex), "target"),
                          data = train.hex, family = "binomial", alpha = 1,
                          lambda_search = T, higher_accuracy = T,return_all_lambda = T,
                          link = "logit",variable_importances = TRUE)
# best lambda based on AIC 0.0002785902
# alpha = 1 checked in range (0,1,0.05)
#auc = 84.78%
best_model = GLM_Model.hexL1@best_model
model = GLM_Model.hexL1@models[[best_model]]
best_threshold = GLM_Model.hexL1@models[[best_model]]$best_threshold
best_threshold #0.3031539
best_lambda = GLM_Model.hexL1@model$params$lambda_best
best_lambda #0.0001738306
# Predict on same training data set
train_predict.hex = h2o.predict(model, 
                                newdata = train.hex[,setdiff(names(train.hex), "target")])
# Copy predictions from H2O to R
train_pred_GLM = as.data.frame(train_predict.hex$predict)
#Confusion Matrix
conf_Matrix_GLM = table(train_pred_GLM$predict,train_glm$target)
#Error Metrics
accuracy_train_glmbest = sum(diag(conf_Matrix_GLM))/sum(conf_Matrix_GLM) *100
recall_train_glmbest = conf_Matrix_GLM[2,2]/sum(conf_Matrix_GLM[,2])*100
fpr_Train_glmbest = conf_Matrix_GLM[2,1]/sum(conf_Matrix_GLM[,1])*100
accuracy_train_glmbest #77.96571
recall_train_glmbest #  76.09166
fpr_Train_glmbest # 21.16575
## test predictions and accuracy and recall
test_predict.hex = h2o.predict(model, 
                                newdata = test.hex[,setdiff(names(test.hex), "target")])
# Copy predictions from H2O to R
test_pred_GLM = as.data.frame(test_predict.hex$predict)
#Confusion Matrix
conf_Matrix_GLM_test = table(test_pred_GLM$predict,test_glm$target )
#Error Metrics
accuracy_test_glmbest = sum(diag(conf_Matrix_GLM_test))/sum(conf_Matrix_GLM_test) *100
recall_test_glmbest = conf_Matrix_GLM_test[2,2]/sum(conf_Matrix_GLM_test[,2])*100
fpr_test_glmbest = conf_Matrix_GLM_test[1,2]/sum(conf_Matrix_GLM_test[,1])*100
accuracy_test_glmbest #77.66667
recall_test_glmbest #74.73684
fpr_test_glmbest #  11.57073
maxlift_glmbest = recall_test_glmbest/apr
maxlift_glmbest

model_performances = rbind(model_performances,c("glmnet best model with alpha 1",accuracy_train_glmbest,
                                                recall_train_glmbest,fpr_Train_glmbest,accuracy_test_glmbest,
                                                recall_test_glmbest,fpr_test_glmbest,maxlift_glmbest))
#### glmnet on vif < 8 data####
train_data_v8 = subset(vif_lessthan_8,split1==TRUE)
test_data_v8= subset(vif_lessthan_8, split1 == FALSE)
write.csv(train_data_v8,"train_data_v8.csv",row.names=F)
write.csv(test_data_v8,"test_data_v8.csv",row.names=F)
localH2O = h2o.init(ip = "localhost", port = 54321, startH2O = TRUE,
                    min_mem_size = "3g")
localH2O = h2o.init()

train.hex_v8  = h2o.uploadFile(localH2O, path = "train_data_v8.csv",header = TRUE, sep = ",")
test.hex_v8  = h2o.uploadFile(localH2O, path = "test_data_v8.csv",header = TRUE, sep = ",")


## grid search for glm on vif<8####
gridt = Sys.time()

GLM_Model.hexL1_search = h2o.glm(y = "target", x = setdiff(names(train.hex_v8), "target"),
                          data = train.hex_v8,
                          #nfolds = 15,
                          family = "binomial", alpha = 0.55,
                          lambda_search = T, higher_accuracy = T,return_all_lambda = T,
                          link = "logit",variable_importances = TRUE)
grid_time = Sys.time() - gridt
beep(8)
GLM_Model.hexL1_search
# ## best model
#model_key alpha   lambda_min lambda_max lambda_best iterations      aic       auc
# 12 GLMGridResults__80270d20fc3e5137417767dbedbf433d_11  0.55 3.343765e-05  0.3343765 0.008881333        103 16332.84 0.8281898
best_model_v8 = h2o.glm(y = "target", x = setdiff(names(train.hex_v8), "target"),
                             data = train.hex_v8, family = "binomial", alpha = 0.55,
                             lambda = 0.008881333, higher_accuracy = T,return_all_lambda = T,
                             link = "logit",variable_importances = TRUE)

# selecting the best model
best_model_v8 = GLM_Model.hexL1_v8@models[[best_model]]

# Predict on same training data set
train_predict.hex_v8 = h2o.predict(best_model_v8, 
                                newdata = train.hex_v8[,setdiff(names(train.hex_v8), "target")])
# Copy predictions from H2O to R
train_pred_GLM_v8 = as.data.frame(train_predict.hex_v8$predict)
#Confusion Matrix
conf_Matrix_GLM_v8 = table(train_pred_GLM_v8$predict,train_glm$target)
#Error Metrics
accuracy_train_v8 = sum(diag(conf_Matrix_GLM_v8))/sum(conf_Matrix_GLM_v8) *100
recall_Train_v8 = conf_Matrix_GLM_v8[2,2]/sum(conf_Matrix_GLM_v8[,2])*100
fpr_Train_v8 = conf_Matrix_GLM_v8[2,1]/sum(conf_Matrix_GLM_v8[,1])*100
accuracy_train_v8 # 77.10286
# with best model 76.89143
# with alpha = 0.55 and 5 fold =76.41143
recall_Train_v8 #  70.26344
# with best model 71.31
# with alpha = 0.55 and 5 fold =72.68134
fpr_Train_v8 # 19.72738
# with best model  20.52183
# with alpha = 0.55 and 5 fold = 21.85984
## test predictions and accuracy and recall
test_predict.hex_v8 = h2o.predict(best_model_v8, 
                               newdata = test.hex_v8[,setdiff(names(test.hex_v8), "target")])
# Copy predictions from H2O to R
test_pred_GLM_v8 = as.data.frame(test_predict.hex_v8$predict)
#Confusion Matrix
conf_Matrix_GLM_test_v8 = table(test_pred_GLM_v8$predict,test_glm$target )
#Error Metrics
accuracy_test_v8 = sum(diag(conf_Matrix_GLM_test_v8))/sum(conf_Matrix_GLM_test_v8) *100
recall_test_v8 = conf_Matrix_GLM_test_v8[2,2]/sum(conf_Matrix_GLM_test_v8[,2])*100
fpr_test_v8 = conf_Matrix_GLM_test_v8[1,2]/sum(conf_Matrix_GLM_test_v8[,1])*100
accuracy_test_v8 #76.70667
# with best model 76.50667
# with alpha = 0.55 and 5 fold = 76.09333
recall_test_v8 #69.22105
# with best model 70.18947
#with alpha = 0.55 and 5 fold = 71.95789
fpr_test_v8 # 14.26341
#13.81463
# with best model
#with alpha = 0.55 and 5 fold = 12.99512
### 10 and 15 fold metrics are not very different from the 5 fold ones
maxlift_glmnet_viflessthan8 = recall_test_v8/apr
maxlift_glmnet_viflessthan8

model_performances= rbind(model_performances,c("glmnet best model on 22 attributes",accuracy_train_v8,
                                               recall_Train_v8,fpr_Train_v8,accuracy_test_v8,
                                               recall_test_v8,fpr_test_v8,maxlift_glmnet_viflessthan8))


##### clustering ####
pca_3 = pca_5[,1:3]
tc = Sys.time()
w = 0 
for (i in 1:100){
    data_clust = kmeans(pca_3[,-ncol(pca_3)],centers = i)
    w[i] = data_clust$tot.withinss
}
plot(1:100,w,type="b",xlab = "Number of Clusters",ylab = "Withiness of Cluster")
Sys.time() - tc
beep(4)
# screeplot shows drop in withinness after 20 clusters, taking 20 clusters
#attaching the cluster centers to the data
data_clust = kmeans(pca_3,centers = 20,iter.max = 30)
clustered_data = data.frame(pca_3,cluster =data_clust$cluster,
                            "target" = churn_stand$target)
head(clustered_data)
table(pca_5$target)
tapply(pca_5$target,clustered_data$cluster,function(x) table(x)[2]/sum(table(x))*100)
#install.packages("fpc")
#install.packages("cluster")
jpeg("Clustered data.jpeg",height = 550,width = 1000,quality = 100)
plotcluster(pca_5[,-ncol(pca_5)],clustered_data$cluster,xlab = " ",ylab = " ",main= "20 clusters of data after PCA using 3 components")
dev.off()
## taking 1 cluster
for (i in 1:20)
{
    cluster1 = filter(clustered_data,cluster == i)
    set.seed(100);s1 = sample.split(cluster1$target,SplitRatio = 0.7)
    cluster1_train = subset(cluster1,s1 == T)
    cluster1_test = subset(cluster1,s1 == F)
    glm_train1 = glm(target~.,data = cluster1_train,family = "binomial")
    summary(glm_train1)
    glm_train1_pred = predict(glm_train1,cluster1_train[,-ncol(cluster1_train)],type = "response")
    ROCR_c1_pred = prediction(glm_train1_pred,cluster1_train$target)
    ROCR_c1_perf = performance(ROCR_c1_pred,'tpr','fpr')
    jpeg(paste("GLM ROCR performance chart for cluster",i,"train.jpeg"),height = 550,width = 1000,quality = 100)
    plot(ROCR_c1_perf,colorize= T,print.cutoffs.at = seq(0,1,0.1))
    dev.off()
    table(glm_train1_pred>0.1,cluster1_train$target)
}
 ## glm doesnt perform well on the clustered data

## random forest on clustered data####
rm(rf_cluster_metrics)
rf_cluster_metrics= data.frame("Cluster Number" = NA,"Ntrees" = NA,"Train_Accuracy"=NA,"Train_Recall"=NA,"Train_FPR"=NA,
                       "Test_Accuracy"=NA,"Test_Recall"=NA,"Test_FPR"=NA,"Lift" = NA)

for (i in 1:10)
{
    cluster1 = filter(clustered_data,cluster == i)
    set.seed(100);s1 = sample.split(cluster1$target,SplitRatio = 0.7)
    cluster1_train = subset(cluster1,s1 == T)
    cluster1_test = subset(cluster1,s1 == F)
    rf = randomForest(target~.,data = cluster1_train,ntrees = 50)
    rf_train_pred = predict(rf)
    rf_train_table = table(rf_train_pred,cluster1_train$target)
    accuracy_rf_train_c = sum(diag(rf_train_table))/sum(rf_train_table)
    recall_train_rf_c = rf_train_table[2,2]/sum(rf_train_table[,2])
    fpr_train_rf_c = rf_train_table[2,1]/sum(rf_train_table[,1])
    
    rf_test_pred = predict(rf,cluster1_test[,-ncol(cluster1_test)])
    rf_test_table = table(rf_test_pred,cluster1_test$target)
    accuracy_rf_test_c = sum(diag(rf_test_table))/sum(rf_test_table)
    recall_test_rf_c = rf_test_table[2,2]/sum(rf_test_table[,2])
    fpr_test_rf_c = rf_test_table[2,1]/sum(rf_test_table[,1])
    
    rf_cluster_metrics = rbind(rf_cluster_metrics,c(i,50,accuracy_rf_train_c,recall_train_rf_c,
                                                    fpr_train_rf_c,accuracy_rf_test_c,recall_test_rf_c,fpr_test_rf_c,recall_test_rf_c/apr))
    #   
}
rf_cluster_metrics = na.omit(rf_cluster_metrics)
rfc = rf_cluster_metrics
rfc[,-c(1,2,ncol(rfc))] = apply(rfc[,-c(1,2,ncol(rfc))],2,function(x)round(x*100,2))
rfc
#head(rf1)
#apply(rf1,2,max)
# writin the error metrics to a file 
write.csv(rfc,"Error metrics for random forest on clustered data for 20 clusters.csv",row.names = F)


## svm on clustered data ####
rm(svm_cluster_metrics)
svm_cluster_metrics= data.frame("Cluster Number" = NA,"Train_Accuracy"=NA,"Train_Recall"=NA,"Train_FPR"=NA,
                               "Test_Accuracy"=NA,"Test_Recall"=NA,"Test_FPR"=NA,"lift"=NA)

for (i in 1:20)
{
    cluster1 = filter(clustered_data,cluster == i)
    set.seed(100);s1 = sample.split(cluster1$target,SplitRatio = 0.7)
    cluster1_train = subset(cluster1,s1 == T)
    cluster1_test = subset(cluster1,s1 == F)
    svm = svm(target~.,data = cluster1_train[,-3],method = "classification")
    svm_train_pred = predict(svm,cluster1_train[,-ncol(cluster1_train)],type = "response")
    svm_train_table = table(svm_train_pred,cluster1_train$target)
    accuracy_svm_train_c = sum(diag(svm_train_table))/sum(svm_train_table)
    recall_train_svm_c = svm_train_table[2,2]/sum(svm_train_table[,2])
    fpr_train_svm_c = svm_train_table[2,1]/sum(svm_train_table[,1])
    
    svm_test_pred = predict(svm,cluster1_test[,-ncol(cluster1_test)],type="response")
    svm_test_table = table(svm_test_pred,cluster1_test$target)
    accuracy_svm_test_c = sum(diag(svm_test_table))/sum(svm_test_table)
    recall_test_svm_c = svm_test_table[2,2]/sum(svm_test_table[,2])
    fpr_test_svm_c = svm_test_table[2,1]/sum(svm_test_table[,1])
    
    svm_cluster_metrics = rbind(svm_cluster_metrics,c(i,accuracy_svm_train_c,recall_train_svm_c,
                                                    fpr_train_svm_c,accuracy_svm_test_c,recall_test_svm_c,fpr_test_svm_c,recall_test_svm_c/apr))
    #   
}
svm_cluster_metrics = na.omit(svm_cluster_metrics)
svmc = svm_cluster_metrics
svmc[,-c(1,ncol(svmc))] = apply(svmc[,-c(1,ncol(svmc))],2,function(x)round(x*100,2))
svmc
#head(svm1)
#apply(svm1,2,max)
# writin the error metrics to a file 
write.csv(svmc,"Error metrics for svm on clustered data for 20 clusters.csv")

### auto Encoders on VIF < 8 data ####


# Initiate h2o process - can assign ip/port/max_mem_size(ram size)/
# nthreads(no. of processor cores; 2-2core;-1 -all cores available)
localh2o <- h2o.init(ip='localhost', port = 54321, max_mem_size = '1g',
                     nthreads = 1)

aec <- h2o.deeplearning(x = setdiff(colnames(train.hex_v8), "target"), 
                        y = "target", data = train.hex_v8,
                        autoencoder = T, activation = "RectifierWithDropout",
                        classification = T, hidden = c(50),
                        epochs = 100, l1 = 0.01)

#Adding features to train and test data sets
# Extract features from train data
features_train <- as.data.frame.H2OParsedData(h2o.deepfeatures(train.hex_v8[,-23],
                                                               model = aec))
# Extract features from test data
features_test <- as.data.frame.H2OParsedData(h2o.deepfeatures(test.hex_v8[,-23],
                                                              model = aec))

# add extracted features with original data to train the model
train<-data.frame(train_data_v8,features_train)
test<-data.frame(test_data_v8,features_test)
#Converting new R object(includes features) to an H2O Object
train.hex <- as.h2o(localh2o, object = train, key = "train.hex")
test.hex <- as.h2o(localh2o, object = test, key = "test.hex")
tae = Sys.time()
rm(errormetrics_autoencoders_nn)
errormetrics_autoencoders_nn = data.frame("Number of hidden nodes" = NA,"Train_Accuracy"=NA,"Train_Recall"=NA,"Train_FPR"=NA,
                                          "Test_Accuracy"=NA,"Test_Recall"=NA,"Test_FPR"=NA,"lift"=NA)

for (i in 10:15)
{
    h2omodel = h2o.deeplearning(x = setdiff(colnames(train.hex), "target"), 
                         y = "target",
                         data = train.hex, 
                         # activation =  "Tanh", 
                         hidden = c(i),
                         activation = "RectifierWithDropout",
                         input_dropout_ratio = 0.1, 
                         epochs = 100,seed=123)
    prediction_h20_train = h2o.predict(h2omodel, newdata = train.hex)
# Convert prediction from h2o object to R object/dataframe
    pred_h2o_train = as.data.frame(prediction_h20_train)
    
    pred_h2o_train_table = table(pred_h2o_train$predict,train$target)
## h20 train accuracy ,precision,recall ####
    accuracy_train_h2o = sum(diag(pred_h2o_train_table))/sum(pred_h2o_train_table)*100
    accuracy_train_h2o 
#for c(10,10,10,)74.42286
# for c(10) 78.58857
    recall_train_h20 = pred_h2o_train_table[2,2]/sum(pred_h2o_train_table[,2])*100
    recall_train_h20
#for c(10,10,10,)23.1144
# for c(10) 50.70372
    fpr_train_h20 = pred_h2o_train_table[2,1]/sum(pred_h2o_train_table[1,])*100
    fpr_train_h20 
#for c(10,10,10,)1.343414
# for c(10)  7.422303

## for test 
    prediction_h20_test = h2o.predict(h2omodel, newdata = test.hex)
# Convert prediction from h2o object to R object/dataframe
    pred_h2o_test = as.data.frame(prediction_h20_test)
   
    pred_h2o_test_table = table(pred_h2o_test$predict,test$target)
## h20 test accuracy ,precision,recall ####
    accuracy_test_h2o = sum(diag(pred_h2o_test_table))/sum(pred_h2o_test_table)*100
    accuracy_test_h2o 
# for c(10,10,10,)74.44
# for c(10) 78.56
    recall_test_h20 = pred_h2o_test_table[2,2]/sum(pred_h2o_test_table[,2])*100
    recall_test_h20 
#for c(10,10,10,)23.32632
# for c(10) 50.65263
    fpr_test_h20 = pred_h2o_test_table[2,1]/sum(pred_h2o_test_table[1,])*100
    fpr_test_h20 
#for c(10,10,10,)1.40146
# for c(10) 7.439004
    errormetrics_autoencoders_nn = rbind(errormetrics_autoencoders_nn,c(i,accuracy_train_h2o,
                                                                        recall_train_h20,fpr_train_h20,
                                                                        accuracy_test_h2o,
                                                                        recall_test_h20,
                                                                        fpr_test_h20,recall_test_h20/apr))
}
errormetrics_autoencoders_nn = na.omit(errormetrics_autoencoders_nn)

write.csv(errormetrics_autoencoders_nn,"errormetrics_autoencoders_nn.csv",row.names = F)
Sys.time() - tae
beep(4)

#### SVM on auto encoders data ####

#train<-data.frame(train_data_v8,features_train)
#test<-data.frame(test_data_v8,features_test)
train = train[,c(setdiff(colnames(train),"target"),"target")]
test = test[,c(setdiff(colnames(test),"target"),"target")]
svm_autoenc = svm(target~.,data= train,method = "classification")
pred_svm_train = predict(svm_autoenc,train[,-ncol(train)],type = "class")
pred_svm_train_table = table(pred_svm_train,train$target)
accuracy_svm_aec_train = sum(diag(pred_svm_train_table))/sum(pred_svm_train_table)*100
recall_svm_aec_train = pred_svm_train_table[2,2]/sum(pred_svm_train_table[,2]) *100
fpr_svm_aec_train = pred_svm_train_table[2,1]/sum(pred_svm_train_table[1,])*100
accuracy_svm_aec_train # 99.76571
recall_svm_aec_train # 99.29628
fpr_svm_aec_train # 0.01667361
# test 
pred_svm_test = predict(svm_autoenc,test[,-ncol(test)],type = "class")
pred_svm_test_table = table(pred_svm_test,test$target)
accuracy_svm_aec_test = sum(diag(pred_svm_test_table))/sum(pred_svm_test_table)*100
recall_svm_aec_test = pred_svm_test_table[2,2]/sum(pred_svm_test_table[,2]) *100
fpr_svm_aec_test = pred_svm_test_table[2,1]/sum(pred_svm_test_table[1,])*100
accuracy_svm_aec_test # 68.8
recall_svm_aec_test # 2.189474
fpr_svm_aec_test #0.2287714
maxlift_svmonaec = recall_svm_aec_test/apr
model_performances = rbind(model_performances,c("SVM on additional 50 features generated from autoencoders",
                                                accuracy_svm_aec_train,recall_svm_aec_test,fpr_svm_aec_test,
                                                accuracy_svm_aec_test,recall_svm_aec_test,fpr_svm_aec_test,
                                                maxlift_svmonaec))
model_performances = read.csv("Model_performances.csv",header = T)

model_performances = model_performances[1:13,]
filter(model_performances,Max.lift==max(Max.lift))

#### dtrees ####
rpart_model = rpart(target~.,data= train_data, method = "class" )
rpart_model
summary(rpart_model)

rpart_train_pred = predict(rpart_model,train_data[,-ncol(train_data)],type ="class")
rpart_train_pred_table = table(rpart_train_pred,train_data$target)
accuracy_rpart_train = sum(diag(rpart_train_pred_table))/sum(rpart_train_pred_table)*100
recall_rpart_train = (rpart_train_pred_table[2,2])/sum(rpart_train_pred_table[,2])*100
fpr_rpart_train = rpart_train_pred_table[2,1]/sum(rpart_train_pred_table[,1])*100

rpart_test_pred = predict(rpart_model,test_data[,-ncol(test_data)],type ="class")
rpart_test_pred_table = table(rpart_test_pred,test_data$target)
accuracy_rpart_test = sum(diag(rpart_test_pred_table))/sum(rpart_test_pred_table)*100
recall_rpart_test = (rpart_test_pred_table[2,2])/sum(rpart_test_pred_table[,2])*100
fpr_rpart_test = rpart_test_pred_table[2,1]/sum(rpart_test_pred_table[,1])*100

maxlift_rpart = recall_rpart_test/apr
maxlift_rpart
## on all the data
all_train = subset(churn_stand,s==TRUE)
all_test = subset(churn_stand)
rpart_model = rpart(target~.,data= all_train, method = "class" )
rpart_model
summary(rpart_model)

rpart_train_pred = predict(rpart_model,all_train[,-ncol(all_train)],type ="class")
rpart_train_pred_table = table(rpart_train_pred,all_train$target)
accuracy_rpart_train = sum(diag(rpart_train_pred_table))/sum(rpart_train_pred_table)*100
recall_rpart_train = (rpart_train_pred_table[2,2])/sum(rpart_train_pred_table[,2])*100
fpr_rpart_train = rpart_train_pred_table[2,1]/sum(rpart_train_pred_table[,1])*100
accuracy_rpart_train #78.04
recall_rpart_train #56.40563
fpr_rpart_train #11.93343
rpart_test_pred = predict(rpart_model,all_test[,-ncol(all_test)],type ="class")
rpart_test_pred_table = table(rpart_test_pred,all_test$target)
accuracy_rpart_test = sum(diag(rpart_test_pred_table))/sum(rpart_test_pred_table)*100
recall_rpart_test = (rpart_test_pred_table[2,2])/sum(rpart_test_pred_table[,2])*100
fpr_rpart_test = rpart_test_pred_table[2,1]/sum(rpart_test_pred_table[,1])*100
accuracy_rpart_test #77.8
recall_rpart_test # 54.90526
fpr_rpart_test #11.59024

maxlift_rpart = recall_rpart_test/apr
maxlift_rpart


#### ensemble
trainpreds = data.frame(train_pred_GLM,svm_pred_train,lasso_train_pred,ridge_pred_train,train_glm$target)
ensemble = svm(train_glm.target~.,data = trainpreds,method= "classification")
ensemble
ens_train_pred = predict(ensemble,trainpreds)
ens_train_table = table(ens_train_pred,train_glm$target)
ens_train_accuracy = sum(diag(ens_train_table))/sum(ens_train_table)*100
ens_train_accuracy
ens_train_recall = ens_train_table[2,2]/sum(ens_train_table[,2])*100
ens_train_recall
ens_train_fpr = ens_train_table[2,1]/sum(ens_train_table[,1])*100
ens_train_fpr

####### bst
train_glm = subset(churn_stand,s==TRUE)
test_glm = subset(churn_stand, s == FALSE)


bst_model = bst(y= train_glm$target,x= train_glm[,-ncol(train_glm)],family = "binom")
bst_train_pred = predict(bst_model,train_glm)
bst_train_table = 
bst_test_pred = predict(bst_model,test_glm)

### xgboost
train_glm = subset(churn_stand,s==TRUE)
test_glm = subset(churn_stand, s == FALSE)
x_train = as.matrix(train_glm[,-ncol(train_glm)])
y_train = as.integer(as.character(train_glm$target))
x_test = as.matrix(test_glm[,-ncol(test_glm)])

cv.nround <- 5
cv.nfold <- 3

bst.cv = xgb.cv(param=param, data = x_train, label = y_train, 
                nfold = cv.nfold, nrounds = cv.nround)

nround = 50
param <- list(objective = "binary:logistic")
xgb_model = xgboost(params = param,data = x_train,
                    label=y_train,nrounds = 50)
xgb_model
names = dimnames(x_train)[[2]]
importance_matrix <- xgb.importance(names, model = xgb_model)
importance_matrix[1:20]
xgb.plot.importance(importance_matrix)
predict(xgb_model,newdata = x_test)

dtrain = xgb.DMatrix(as.matrix(train_glm[,-ncol(train_glm)]),label= train_glm$target )
dtest = xgb.DMatrix(as.matrix(test_glm[,-ncol(test_glm)]),label= test_glm$target )
    
xgb = xgb.train(param,dtrain,nrounds = nround)

### gbm ####
gbm_model = gbm(target~., data = train_data,
                     # see the help for other choices
                distribution = "bernoulli",
                data = list(),
                weights,
                var.monotone = NULL,
                n.trees = 100,
                interaction.depth = 1,
                n.minobsinnode = 10,
                shrinkage = 0.001,
                bag.fraction = 0.5,
                train.fraction = 1.0,
                cv.folds=0,
                keep.data = TRUE,
                verbose = "CV",
                class.stratify.cv=NULL,
                n.cores = NULL)

best.iter <- gbm.perf(gbm_model,method="test")

gbm_train_pred = predict(gbm_model,train_glm[,-ncol(train_glm)],best.iter)
