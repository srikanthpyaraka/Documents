####Best Model ####
rm(list=ls())
#### loading required libraries ####
library(dplyr)
library(reshape2)
library(caTools)
library(vegan)
library(psych)
library(ROCR)
library(dplyr)
library(DAAG)
library(MASS)
library(stats)
library(glmnet)
library(h2o)
library(randomForest)
library(ggplot2)

#### Setting working directory
setwd("F:/INSOFE/INSOFE Notes & Activity sheets/Major Projects/Telecom_Churn_Data/data")
#### Load data in csv format in to R's memory
churn = read.csv("Data.csv",header = T)
##-----------------Preprocessing steps-----------------####
#Ckecking for dimensions of data
dim(churn) # 25000 rows and 111 columns,including target
#summary of data
summary(churn) 
#Structure of data
str(churn) # all variables are loded as int or num
#Checking for NA values
sum(is.na(churn)) # 0
# check for duplicates
if(nrow(unique(churn)) == nrow(churn)){
    print("No Duplicates")
}
#Moving the target variable to the last column for ease of indexing
churn = churn[,c(setdiff(names(churn),"target"),"target")]
names(churn)
#Converting everything except target into numeric
churn[,-ncol(churn)] = apply(churn[,-ncol(churn)],2,as.numeric)
#Converting target to factor
churn$target = as.factor(churn$target)
#Setting seed to enable reconstruction of the model
set.seed(100)
#Checking for class imbalance
table(churn$target)
#Checking for the percantage of churned customers in the data
apr = table(churn$target)[2]/sum(table(churn$target))*100 #31.668
#Splitting the data using stratified sampling technique
set.seed(100);s = sample.split(churn$target,SplitRatio = 0.7)

##--------------------Standardizing the data--------------------####
churn_stand = decostand(churn[,-ncol(churn)],method = "standardize")
churn_stand$target = churn$target
##-------------------------Plots-------------------------####
# Plotting standardized data
df3 = churn_stand[s,c(1:50,ncol(churn_stand))]
df3.m = melt(df3,id.vars = "target")

#jpeg("Boxplot of Standardized Churn data for 1-50 attributes.jpeg",height = 550,width = 1000,quality = 100)
ggplot(df3.m,aes(x=variable,y= value),las=2,cex = 0.2) +
    coord_cartesian(ylim=c(-4,6))+
    geom_boxplot(aes(fill=df3.m$target))+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))+
    labs(title = "Boxplot of Standardized Churn data for 1-50 attributes")
#dev.off()

df4 = churn_stand[s,c(51:ncol(churn_stand))]
df4.m = melt(df4,id.vars = "target")
#jpeg("Boxplot of Standardized Churn data for 51-100 attributes.jpeg",height = 550,width = 1000,quality = 100)
ggplot(df4.m,aes(x=variable,y= value),las=2,cex = 0.2) +
    coord_cartesian(ylim=c(-4,6))+
    geom_boxplot(aes(fill=df4.m$target))+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))+
    labs(title = "Boxplot of Standardized Churn data for 1-50 attributes")
#dev.off()

# Checking for outliers in the standardized data
x = apply(churn_stand[,-ncol(churn_stand)],2,function (x) boxplot(x)$out)

#boxplot(churn[,-ncol(churn)]) # with all the data
outlier_data = lapply(churn_stand[,-ncol(churn_stand)],function (x) boxplot(x)$out)
outliers_in_each =data.frame("Number of Outliers" = sapply(outlier_data,length))
outliers_in_each$Attribute = rownames(outliers_in_each)

#ordering the columns in descending order of the outliers
outliers_in_each = outliers_in_each[order(outliers_in_each$Number.of.Outliers,decreasing = T),]
outliers_in_each = outliers_in_each[,c(2,1)]
## writing the number of outliers into a csv file
#write.csv(outliers_in_each,"Number of outliers in each after stand.csv",row.names = F)
# top 10 columns with outliers
outliers_in_each[1:10,]
## The data doesnt follow normal distribution.

## checking for correlation among attributes
library(corrplot)

cor_mat = cor(churn_stand[,-ncol(churn_stand)])

diag(cor_mat) = 0
cor.plot(cor_mat)

##--------Logistic Regression on all the attributes-----------####
#Taking stratified sample as there is a class imbalance

train_glm = subset(churn_stand,s==TRUE)
test_glm = subset(churn_stand, s == FALSE)

glm_model = glm(target~.,data= train_glm,family = "binomial")
summary(glm_model)

pred_train_glm_model = predict(glm_model,train_glm,type= "response")
####Performance of glm_model ROCR curve and AUC

ROCR_glm_model_pred = prediction(pred_train_glm_model,train_glm$target)
ROCR_glm_model_perf = performance(ROCR_glm_model_pred,'tpr','fpr')
## AUC of glm model
AUC_logreg_model = as.numeric(performance(ROCR_glm_model_pred,'auc')@y.values) *100 
AUC_logreg_model #85.65973
jpeg("ROCR curve for logistic regression using all the variables.jpeg",height = 550,width = 1000,quality = 100)
plot(ROCR_glm_model_perf,colorize= T,print.cutoffs.at=c(seq(0,1,0.1)),
     main="ROCR curve for Logistic Regression using all the variables(on train data)")
dev.off()
#In the performance object, we have the slot alpha values, 
#which corresponds to the cutoff in this case, and y.values correspond to 
# 'tpr' rates, x.values corr to 'fpr' rates.

cutoffs1 = data.frame(cut=ROCR_glm_model_perf@alpha.values[[1]], fpr=ROCR_glm_model_perf@x.values[[1]], 
                      tpr=ROCR_glm_model_perf@y.values[[1]])
cutoffs1 = cutoffs1[order(cutoffs1$tpr, decreasing=TRUE),]

filter(cutoffs1,fpr<0.19,tpr>0.7)

#Considering 0.3 cutoff 
##Train accuracy for glm 
pred_train_glm_model_table = table(pred_train_glm_model>0.30,train_glm$target)
accu_train_glm = sum(diag(pred_train_glm_model_table))/sum(pred_train_glm_model_table)*100
accu_train_glm #  77.13714
##Train recall for glm
recall_train_glm = pred_train_glm_model_table[2,2]/sum(pred_train_glm_model_table[,2])*100
recall_train_glm #78.32912
##Fpr for glm 
fpr_glm_train = pred_train_glm_model_table[2,1]/sum(pred_train_glm_model_table[,1])*100
fpr_glm_train #18.92457
## test accuracy for glm
pred_test_glm_model = predict(glm_model,test_glm[,-ncol(test_glm)],type = "response")
pred_test_glm_model_table = table(pred_test_glm_model>0.3,test_glm$target)
accu_test_glm = sum(diag(pred_test_glm_model_table))/sum(pred_test_glm_model_table)*100
accu_test_glm #77.14667
recall_test_glm = pred_test_glm_model_table[2,2]/sum(pred_test_glm_model_table[,2])*100
recall_test_glm #78.14737
fpr_glm_test = pred_test_glm_model_table[2,1]/sum(pred_test_glm_model_table[,1])*100
fpr_glm_test #23.31707
##Max lift with log reg model
maxlift_logreg  = recall_test_glm/apr
maxlift_logreg #2.467708 
#Saving the metrics in list
logregmetrics = c(accu_train_glm,recall_train_glm,fpr_glm_train,accu_test_glm,
                  recall_test_glm,fpr_glm_test,maxlift_logreg)


####--------VIF on glm model----------####
vif_glm = vif(glm_model)
##Considering all the attrbutes whose correlation is less than 0.875 i.e vif < 8
vif_lessthan_8 = data.frame(churn_stand[,vif_glm<8],"target" =churn_stand$target)

colnames(vif_lessthan_8)

### Random Forest ####
# random forest on all the attributes
train_rf = train_glm
test_rf = test_glm

randomForest_churn = randomForest(target~.,data=train_rf ,ntree= 12)
varimp = data.frame(varImpPlot(randomForest_churn))
varimp$names = rownames(varimp)
top = varimp[order(varimp$MeanDecreaseGini,decreasing = T),]
#varimp plot
varImpPlot(randomForest_churn,main ="Variable importance plot")
#jpeg("Variable importance plot.jpeg",width = 650,height = 750,quality = 100)
varImpPlot(randomForest_churn,main ="Variable importance plot")
#dev.off()
#writing the var imp to file
top = top[c(2,1)]
write.csv(top,"var_imp_decreasing_order.csv",row.names = F)
top$names[1:22]
colnames(vif_lessthan_8)[1:22]
x = 0
for (i in colnames(vif_lessthan_8)){
    if (i %in% top$names[1:22]){x=x+1}
}
#only 6 of the attributes match
####-----------------------H2o glm-----------------------------####
# Start H2O on the local machine using all available cores
#localH2O = h2o.init(nthreads = -1)


####-----------Logistic Regression for vif<8  attributes----------####
train_data = subset(vif_lessthan_8,s==TRUE)
test_data= subset(vif_lessthan_8, s == FALSE)
ncol(train_data)

vglm_train_model = glm(target~.,data = train_data,family = "binomial")

## ROCR for low VIF model 

vglm_model_train_pred = predict(vglm_train_model,train_data,type="response")

ROCR_lowvif_pred = prediction(vglm_model_train_pred,train_data$target)
ROCR_lowvif_perf = performance(ROCR_lowvif_pred,'tpr','fpr')
#jpeg("ROCR for glm on vif less than 8.jpeg",width = 1000,height = 550,quality = 100)
plot(ROCR_lowvif_perf,colorize= T,print.cutoffs.at=c(seq(0,1,0.2)),main = "ROCR for Logistic Regression (on VIF less than 8 attributes).")
#dev.off()
AUC_low_vif_model = as.numeric(performance(ROCR_lowvif_pred,'auc')@y.values)*100
AUC_low_vif_model # 82.97243

cutoffs2 = data.frame(cut=ROCR_lowvif_perf@alpha.values[[1]], fpr=ROCR_lowvif_perf@x.values[[1]], 
                      tpr=ROCR_lowvif_perf@y.values[[1]])
cutoffs2 = cutoffs2[order(cutoffs2$tpr, decreasing=TRUE),]
filter(cutoffs2,fpr<0.2,tpr>.7)

## using 0.33 cutoff


vglm_train_table = table(vglm_model_train_pred>0.33,train_data$target)
vglm_train_table
accuracy_vglm_train = sum(diag(vglm_train_table))/sum(vglm_train_table)*100
accuracy_vglm_train # 76.44571

recall_vglm_train = vglm_train_table[2,2]/sum(vglm_train_table[,2])*100
recall_vglm_train # 72.17611

fpr_vglm_train = vglm_train_table[2,1]/sum(vglm_train_table[,1])*100
fpr_vglm_train #21.57551

lowvif_glm_model_test_pred = predict(vglm_train_model,test_data[,-ncol(test_data)],type="response")
lowvif_glm_test_table = table(lowvif_glm_model_test_pred >0.33,test_data$target)
lowvif_glm_test_table
accuracy_vgmltest = sum(diag(lowvif_glm_test_table))/sum(lowvif_glm_test_table)*100
accuracy_vgmltest # 76.06667
recall_vglm_test = lowvif_glm_test_table[2,2]/sum(lowvif_glm_test_table[,2])*100
recall_vglm_test # 71.53684
fpr_vglm_test = lowvif_glm_test_table[2,1]/sum(lowvif_glm_test_table[,1])*100
fpr_vglm_test # 21.83415
#max lift 
maxlift_vglm = recall_vglm_test/apr
maxlift_vglm
#saving logistic regression in vif <8 error metrics in alist
logregvif8metrics = c(accuracy_vglm_train,recall_vglm_train,fpr_vglm_train,accuracy_vgmltest,
                      recall_vglm_test,fpr_vglm_test,maxlift_vglm)

#### Glmnet on vif < 8 data####
train_data_v8 = subset(vif_lessthan_8,s==TRUE)
test_data_v8= subset(vif_lessthan_8, s == FALSE)
##Writing the files into the working diretory
write.csv(train_data_v8,"train_data_v8.csv",row.names=F)
write.csv(test_data_v8,"test_data_v8.csv",row.names=F)
##Initializing h2o cluster
localH2O = h2o.init(ip = "localhost", port = 54321, startH2O = TRUE,
                    min_mem_size = "3g")
localH2O = h2o.init()

##Loading the train and test data as h2o object
train.hex_v8  = h2o.uploadFile(localH2O, path = "train_data_v8.csv",header = TRUE, sep = ",")
test.hex_v8  = h2o.uploadFile(localH2O, path = "test_data_v8.csv",header = TRUE, sep = ",")

##Grid search for glm on vif<8####
gridt = Sys.time()

GLM_Model.hexL1_search = h2o.glm(y = "target", x = setdiff(names(train.hex_v8), "target"),
                                 data = train.hex_v8,
                                 family = "binomial",
                                 lambda_search = T, higher_accuracy = T,return_all_lambda = T,
                                 link = "logit",variable_importances = TRUE)
grid_time = Sys.time() - gridt #13.21152 secs
summary(GLM_Model.hexL1_search)
## best model
#alpha = 0.55
#lambda= lambda = 0.008881333
# selecting the best model
h2ostart = Sys.time()
best_model_v8 = h2o.glm(y = "target", x = setdiff(names(train.hex_v8), "target"),
                        data = train.hex_v8, family = "binomial", alpha = 0.55,
                        lambda = 0.008881333, higher_accuracy = T,return_all_lambda = T,
                        link = "logit",variable_importances = TRUE)
h2otime = Sys.time() - h2ostart
h2otime # 1.394012
# Predict on same training data set
train_predict.hex_v8 = h2o.predict(best_model_v8, 
                                   newdata = train.hex_v8[,setdiff(names(train.hex_v8), "target")])
# Copy predictions from H2O to R
train_pred_GLM_v8 = as.data.frame(train_predict.hex_v8$predict)
#Confusion Matrix
conf_Matrix_GLM_v8 = table(train_pred_GLM_v8$predict,train_glm$target)
#Error Metrics
accuracy_train_v8 = sum(diag(conf_Matrix_GLM_v8))/sum(conf_Matrix_GLM_v8) *100
recall_Train_v8 = conf_Matrix_GLM_v8[2,2]/sum(conf_Matrix_GLM_v8[,2])*100
fpr_Train_v8 = conf_Matrix_GLM_v8[2,1]/sum(conf_Matrix_GLM_v8[,1])*100
accuracy_train_v8 # 76.89143
recall_Train_v8 #71.31
fpr_Train_v8 #20.52183
## test predictions and accuracy and recall
h2oteststart = Sys.time()
test_predict.hex_v8 = h2o.predict(best_model_v8, 
                                  newdata = test.hex_v8[,setdiff(names(test.hex_v8), "target")])
h2otesttime = Sys.time() - h2oteststart
h2otesttime
# Copy predictions from H2O to R
test_pred_GLM_v8 = as.data.frame(test_predict.hex_v8$predict)
#Confusion Matrix
conf_Matrix_GLM_test_v8 = table(test_pred_GLM_v8$predict,test_glm$target )
#Error Metrics
accuracy_test_v8 = sum(diag(conf_Matrix_GLM_test_v8))/sum(conf_Matrix_GLM_test_v8) *100
recall_test_v8 = conf_Matrix_GLM_test_v8[2,2]/sum(conf_Matrix_GLM_test_v8[,2])*100
fpr_test_v8 = conf_Matrix_GLM_test_v8[1,2]/sum(conf_Matrix_GLM_test_v8[,1])*100
accuracy_test_v8 # 76.50667
recall_test_v8 # 70.18947
fpr_test_v8 #  13.81463
### 10 and 15 fold metrics are not very different from the 5 fold ones
maxlift_glmnet_viflessthan8 = recall_test_v8/apr
maxlift_glmnet_viflessthan8 #2.216416 

##Saaving the h2o model metrics in a list
h2oglmmetrics = c(accuracy_train_v8, recall_Train_v8,fpr_Train_v8,
                  accuracy_test_v8,
                  recall_test_v8,fpr_test_v8,maxlift_glmnet_viflessthan8)
##Making a dataframe of the performance metrics 
compare_metrics = data.frame(logregmetrics,h2oglmmetrics,logregvif8metrics)
#Converting the data in to numeric
compare_metrics =  apply(compare_metrics,2,as.numeric)
##Rounding off the metrics to 5 digits
compare_metrics = apply(compare_metrics,2, function(x){round(x,5)})
#Adding colnames and rownames
colnames(compare_metrics) =c("Logistic Regression on all attributes",
                             "h2o.glmnet on 22 attributes","Logistic Regression on vif8 attributes")
rownames(compare_metrics) = c("Train Accuracy","Train Recall",
                              "FPR Train","Test Accuracy","Test Recall",
                              "FPR Test","Lift on test")

par(mfrow=c(2,1))
# saving the barplot
jpeg("Performance comparision.jpeg",
     width = 1000,height = 550,quality = 100)
barplot(t(as.matrix(compare_metrics)),las = 1,ylim = c(0,90),
        beside = T,col=c("Black","RED","blue"),
        main= "Logistic Regression on 110 attributes vs Elastic Net on 22 attributes vs Logreg in vif<8 attributes")

legend("topright",cex = 1,
       c("LogReg on 110 attributes","h2oglm on 22 attributes","Logistic regression on 22 attributes"),pch=21)
dev.off()
